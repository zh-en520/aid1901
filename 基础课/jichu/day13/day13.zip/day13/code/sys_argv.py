#! /usr/bin/python3

# sys_argv.py

print("hello")
# 在程序内部能不能得到命令行参数?
import sys
print(sys.argv)

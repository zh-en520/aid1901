# file: mypack/__init__.py


''' 这是mypack包的文档字符串的标题

这是包的内容部分
... 此处省略200字
'''

def myfun():
    print("mypack.myfun被调用")

print("mypack包被加载")

